﻿namespace VisitTheLouvreApplication
{
    partial class Louvre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Louvre));
            this.PictureName = new System.Windows.Forms.ComboBox();
            this.PictureNumber = new System.Windows.Forms.NumericUpDown();
            this.Information = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.mostFamousPaintingsLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.slideshowTimer = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Info = new System.Windows.Forms.TabPage();
            this.PanelPage_Info = new System.Windows.Forms.RichTextBox();
            this.History = new System.Windows.Forms.TabPage();
            this.PanelPage_History = new System.Windows.Forms.RichTextBox();
            this.Prices = new System.Windows.Forms.TabPage();
            this.PanelPage_Prices = new System.Windows.Forms.RichTextBox();
            this.bookButton = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.areWeOpenButton = new System.Windows.Forms.Button();
            this.slideshowOnOffButton = new System.Windows.Forms.Button();
            this.MainPicture = new System.Windows.Forms.PictureBox();
            this.ThirdPicture = new System.Windows.Forms.PictureBox();
            this.SecondPicture = new System.Windows.Forms.PictureBox();
            this.FirstPicture = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PictureNumber)).BeginInit();
            this.Information.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Info.SuspendLayout();
            this.History.SuspendLayout();
            this.Prices.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThirdPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecondPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FirstPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // PictureName
            // 
            resources.ApplyResources(this.PictureName, "PictureName");
            this.PictureName.BackColor = System.Drawing.Color.MistyRose;
            this.PictureName.ForeColor = System.Drawing.Color.IndianRed;
            this.PictureName.FormattingEnabled = true;
            this.PictureName.Items.AddRange(new object[] {
            resources.GetString("PictureName.Items"),
            resources.GetString("PictureName.Items1"),
            resources.GetString("PictureName.Items2"),
            resources.GetString("PictureName.Items3"),
            resources.GetString("PictureName.Items4"),
            resources.GetString("PictureName.Items5"),
            resources.GetString("PictureName.Items6"),
            resources.GetString("PictureName.Items7"),
            resources.GetString("PictureName.Items8"),
            resources.GetString("PictureName.Items9"),
            resources.GetString("PictureName.Items10"),
            resources.GetString("PictureName.Items11")});
            this.PictureName.Name = "PictureName";
            this.PictureName.SelectedIndexChanged += new System.EventHandler(this.PictureName_SelectedIndexChanged);
            // 
            // PictureNumber
            // 
            resources.ApplyResources(this.PictureNumber, "PictureNumber");
            this.PictureNumber.BackColor = System.Drawing.Color.MistyRose;
            this.PictureNumber.ForeColor = System.Drawing.Color.IndianRed;
            this.PictureNumber.Maximum = new decimal(new int[] {
            11,
            0,
            0,
            0});
            this.PictureNumber.Name = "PictureNumber";
            this.PictureNumber.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.PictureNumber.ValueChanged += new System.EventHandler(this.PictureNumber_ValueChanged);
            // 
            // Information
            // 
            resources.ApplyResources(this.Information, "Information");
            this.Information.Controls.Add(this.tabPage1);
            this.Information.Controls.Add(this.tabPage2);
            this.Information.Controls.Add(this.tabPage3);
            this.Information.Name = "Information";
            this.Information.SelectedIndex = 0;
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            resources.ApplyResources(this.richTextBox1, "richTextBox1");
            this.richTextBox1.Name = "richTextBox1";
            // 
            // tabPage2
            // 
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Controls.Add(this.richTextBox2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            resources.ApplyResources(this.richTextBox2, "richTextBox2");
            this.richTextBox2.Name = "richTextBox2";
            // 
            // tabPage3
            // 
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Controls.Add(this.richTextBox3);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // richTextBox3
            // 
            resources.ApplyResources(this.richTextBox3, "richTextBox3");
            this.richTextBox3.Name = "richTextBox3";
            // 
            // monthCalendar1
            // 
            resources.ApplyResources(this.monthCalendar1, "monthCalendar1");
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TitleForeColor = System.Drawing.Color.IndianRed;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // mostFamousPaintingsLabel
            // 
            resources.ApplyResources(this.mostFamousPaintingsLabel, "mostFamousPaintingsLabel");
            this.mostFamousPaintingsLabel.Name = "mostFamousPaintingsLabel";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // slideshowTimer
            // 
            this.slideshowTimer.Interval = 1000;
            this.slideshowTimer.Tick += new System.EventHandler(this.slideshowTimer_Tick);
            // 
            // tabControl1
            // 
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Controls.Add(this.Info);
            this.tabControl1.Controls.Add(this.History);
            this.tabControl1.Controls.Add(this.Prices);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            // 
            // Info
            // 
            resources.ApplyResources(this.Info, "Info");
            this.Info.BackColor = System.Drawing.Color.MistyRose;
            this.Info.Controls.Add(this.PanelPage_Info);
            this.Info.ForeColor = System.Drawing.Color.Crimson;
            this.Info.Name = "Info";
            // 
            // PanelPage_Info
            // 
            resources.ApplyResources(this.PanelPage_Info, "PanelPage_Info");
            this.PanelPage_Info.BackColor = System.Drawing.Color.LightPink;
            this.PanelPage_Info.ForeColor = System.Drawing.Color.Crimson;
            this.PanelPage_Info.Name = "PanelPage_Info";
            this.PanelPage_Info.ReadOnly = true;
            // 
            // History
            // 
            resources.ApplyResources(this.History, "History");
            this.History.BackColor = System.Drawing.Color.MistyRose;
            this.History.Controls.Add(this.PanelPage_History);
            this.History.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.History.Name = "History";
            // 
            // PanelPage_History
            // 
            resources.ApplyResources(this.PanelPage_History, "PanelPage_History");
            this.PanelPage_History.BackColor = System.Drawing.Color.LightPink;
            this.PanelPage_History.ForeColor = System.Drawing.Color.Crimson;
            this.PanelPage_History.Name = "PanelPage_History";
            this.PanelPage_History.ReadOnly = true;
            // 
            // Prices
            // 
            resources.ApplyResources(this.Prices, "Prices");
            this.Prices.BackColor = System.Drawing.Color.MistyRose;
            this.Prices.Controls.Add(this.PanelPage_Prices);
            this.Prices.Name = "Prices";
            // 
            // PanelPage_Prices
            // 
            resources.ApplyResources(this.PanelPage_Prices, "PanelPage_Prices");
            this.PanelPage_Prices.BackColor = System.Drawing.Color.LightPink;
            this.PanelPage_Prices.ForeColor = System.Drawing.Color.Crimson;
            this.PanelPage_Prices.Name = "PanelPage_Prices";
            this.PanelPage_Prices.ReadOnly = true;
            // 
            // bookButton
            // 
            resources.ApplyResources(this.bookButton, "bookButton");
            this.bookButton.BackColor = System.Drawing.Color.LemonChiffon;
            this.bookButton.ForeColor = System.Drawing.Color.Goldenrod;
            this.bookButton.Name = "bookButton";
            this.bookButton.UseVisualStyleBackColor = false;
            this.bookButton.Click += new System.EventHandler(this.bookButton_Click);
            // 
            // dateTimePicker1
            // 
            resources.ApplyResources(this.dateTimePicker1, "dateTimePicker1");
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.IndianRed;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.LightPink;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // areWeOpenButton
            // 
            resources.ApplyResources(this.areWeOpenButton, "areWeOpenButton");
            this.areWeOpenButton.BackColor = System.Drawing.Color.LemonChiffon;
            this.areWeOpenButton.ForeColor = System.Drawing.Color.Goldenrod;
            this.areWeOpenButton.Name = "areWeOpenButton";
            this.areWeOpenButton.UseVisualStyleBackColor = false;
            this.areWeOpenButton.Click += new System.EventHandler(this.areWeOpenButton_Click);
            // 
            // slideshowOnOffButton
            // 
            resources.ApplyResources(this.slideshowOnOffButton, "slideshowOnOffButton");
            this.slideshowOnOffButton.BackColor = System.Drawing.Color.RoyalBlue;
            this.slideshowOnOffButton.ForeColor = System.Drawing.Color.Lavender;
            this.slideshowOnOffButton.Name = "slideshowOnOffButton";
            this.slideshowOnOffButton.UseVisualStyleBackColor = false;
            this.slideshowOnOffButton.Click += new System.EventHandler(this.slideshowOnOffButton_Click);
            // 
            // MainPicture
            // 
            resources.ApplyResources(this.MainPicture, "MainPicture");
            this.MainPicture.ErrorImage = global::VisitTheLouvreApplication.Properties.Resources.Dante;
            this.MainPicture.Image = global::VisitTheLouvreApplication.Properties.Resources.Dante;
            this.MainPicture.InitialImage = global::VisitTheLouvreApplication.Properties.Resources.Dante;
            this.MainPicture.Name = "MainPicture";
            this.MainPicture.TabStop = false;
            // 
            // ThirdPicture
            // 
            resources.ApplyResources(this.ThirdPicture, "ThirdPicture");
            this.ThirdPicture.Image = global::VisitTheLouvreApplication.Properties.Resources.Homer;
            this.ThirdPicture.Name = "ThirdPicture";
            this.ThirdPicture.TabStop = false;
            this.ThirdPicture.Click += new System.EventHandler(this.ThirdPicture_Click);
            // 
            // SecondPicture
            // 
            resources.ApplyResources(this.SecondPicture, "SecondPicture");
            this.SecondPicture.Image = global::VisitTheLouvreApplication.Properties.Resources.Death;
            this.SecondPicture.Name = "SecondPicture";
            this.SecondPicture.TabStop = false;
            this.SecondPicture.Click += new System.EventHandler(this.SecondPicture_Click);
            // 
            // FirstPicture
            // 
            resources.ApplyResources(this.FirstPicture, "FirstPicture");
            this.FirstPicture.Image = global::VisitTheLouvreApplication.Properties.Resources.Dante;
            this.FirstPicture.Name = "FirstPicture";
            this.FirstPicture.TabStop = false;
            this.FirstPicture.Click += new System.EventHandler(this.FirstPicture_Click);
            // 
            // Louvre
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Controls.Add(this.slideshowOnOffButton);
            this.Controls.Add(this.MainPicture);
            this.Controls.Add(this.areWeOpenButton);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bookButton);
            this.Controls.Add(this.mostFamousPaintingsLabel);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Information);
            this.Controls.Add(this.PictureNumber);
            this.Controls.Add(this.PictureName);
            this.Controls.Add(this.ThirdPicture);
            this.Controls.Add(this.SecondPicture);
            this.Controls.Add(this.FirstPicture);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Louvre";
            this.Load += new System.EventHandler(this.Louvre_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Louvre_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.PictureNumber)).EndInit();
            this.Information.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.Info.ResumeLayout(false);
            this.History.ResumeLayout(false);
            this.Prices.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MainPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThirdPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecondPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FirstPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox MainPicture;
        private System.Windows.Forms.PictureBox FirstPicture;
        private System.Windows.Forms.PictureBox SecondPicture;
        private System.Windows.Forms.PictureBox ThirdPicture;
        private System.Windows.Forms.ComboBox PictureName;
        private System.Windows.Forms.NumericUpDown PictureNumber;
        private System.Windows.Forms.TabControl Information;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label mostFamousPaintingsLabel;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Timer slideshowTimer;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Info;
        private System.Windows.Forms.RichTextBox PanelPage_Info;
        private System.Windows.Forms.TabPage History;
        private System.Windows.Forms.RichTextBox PanelPage_History;
        private System.Windows.Forms.TabPage Prices;
        private System.Windows.Forms.RichTextBox PanelPage_Prices;
        private System.Windows.Forms.Button bookButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button slideshowOnOffButton;
        public System.Windows.Forms.Button areWeOpenButton;
    }
}

