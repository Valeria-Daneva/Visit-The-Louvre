﻿namespace VisitTheLouvreApplication
{
    partial class ReservationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReservationForm));
            this.radioButtonPanel = new System.Windows.Forms.Panel();
            this.radioButtonGroup = new System.Windows.Forms.RadioButton();
            this.radioButtonFamily = new System.Windows.Forms.RadioButton();
            this.radioButtonTwoPeople = new System.Windows.Forms.RadioButton();
            this.radioButtonOnePerson = new System.Windows.Forms.RadioButton();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.fullNameTextbox = new System.Windows.Forms.TextBox();
            this.ticketIsForLabel = new System.Windows.Forms.Label();
            this.fullNameLabel = new System.Windows.Forms.Label();
            this.fillThisFormLabel = new System.Windows.Forms.Label();
            this.numberOfPeopleTextbox = new System.Windows.Forms.TextBox();
            this.numberOfPeopleLabel = new System.Windows.Forms.Label();
            this.extrasLabel = new System.Windows.Forms.Label();
            this.doneButton = new System.Windows.Forms.Button();
            this.freeTicketsTextbox = new System.Windows.Forms.TextBox();
            this.freeTicketsLabel = new System.Windows.Forms.Label();
            this.radioButtonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // radioButtonPanel
            // 
            resources.ApplyResources(this.radioButtonPanel, "radioButtonPanel");
            this.radioButtonPanel.BackColor = System.Drawing.Color.LightPink;
            this.radioButtonPanel.Controls.Add(this.radioButtonGroup);
            this.radioButtonPanel.Controls.Add(this.radioButtonFamily);
            this.radioButtonPanel.Controls.Add(this.radioButtonTwoPeople);
            this.radioButtonPanel.Controls.Add(this.radioButtonOnePerson);
            this.radioButtonPanel.ForeColor = System.Drawing.Color.Crimson;
            this.radioButtonPanel.Name = "radioButtonPanel";
            // 
            // radioButtonGroup
            // 
            resources.ApplyResources(this.radioButtonGroup, "radioButtonGroup");
            this.radioButtonGroup.Name = "radioButtonGroup";
            this.radioButtonGroup.TabStop = true;
            this.radioButtonGroup.UseVisualStyleBackColor = true;
            this.radioButtonGroup.CheckedChanged += new System.EventHandler(this.radioButtonGroup_CheckedChanged);
            // 
            // radioButtonFamily
            // 
            resources.ApplyResources(this.radioButtonFamily, "radioButtonFamily");
            this.radioButtonFamily.Name = "radioButtonFamily";
            this.radioButtonFamily.TabStop = true;
            this.radioButtonFamily.UseVisualStyleBackColor = true;
            this.radioButtonFamily.CheckedChanged += new System.EventHandler(this.radioButtonFamily_CheckedChanged);
            // 
            // radioButtonTwoPeople
            // 
            resources.ApplyResources(this.radioButtonTwoPeople, "radioButtonTwoPeople");
            this.radioButtonTwoPeople.Name = "radioButtonTwoPeople";
            this.radioButtonTwoPeople.TabStop = true;
            this.radioButtonTwoPeople.UseVisualStyleBackColor = true;
            this.radioButtonTwoPeople.CheckedChanged += new System.EventHandler(this.radioButtonTwoPeople_CheckedChanged);
            // 
            // radioButtonOnePerson
            // 
            resources.ApplyResources(this.radioButtonOnePerson, "radioButtonOnePerson");
            this.radioButtonOnePerson.Name = "radioButtonOnePerson";
            this.radioButtonOnePerson.TabStop = true;
            this.radioButtonOnePerson.UseVisualStyleBackColor = true;
            this.radioButtonOnePerson.CheckedChanged += new System.EventHandler(this.radioButtonOnePerson_CheckedChanged);
            // 
            // checkedListBox1
            // 
            resources.ApplyResources(this.checkedListBox1, "checkedListBox1");
            this.checkedListBox1.BackColor = System.Drawing.Color.LightPink;
            this.checkedListBox1.ForeColor = System.Drawing.Color.Crimson;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            resources.GetString("checkedListBox1.Items"),
            resources.GetString("checkedListBox1.Items1"),
            resources.GetString("checkedListBox1.Items2"),
            resources.GetString("checkedListBox1.Items3")});
            this.checkedListBox1.Name = "checkedListBox1";
            // 
            // fullNameTextbox
            // 
            resources.ApplyResources(this.fullNameTextbox, "fullNameTextbox");
            this.fullNameTextbox.BackColor = System.Drawing.Color.MistyRose;
            this.fullNameTextbox.ForeColor = System.Drawing.Color.IndianRed;
            this.fullNameTextbox.Name = "fullNameTextbox";
            this.fullNameTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fullNameTextbox_KeyPress);
            // 
            // ticketIsForLabel
            // 
            resources.ApplyResources(this.ticketIsForLabel, "ticketIsForLabel");
            this.ticketIsForLabel.Name = "ticketIsForLabel";
            // 
            // fullNameLabel
            // 
            resources.ApplyResources(this.fullNameLabel, "fullNameLabel");
            this.fullNameLabel.Name = "fullNameLabel";
            // 
            // fillThisFormLabel
            // 
            resources.ApplyResources(this.fillThisFormLabel, "fillThisFormLabel");
            this.fillThisFormLabel.Name = "fillThisFormLabel";
            // 
            // numberOfPeopleTextbox
            // 
            resources.ApplyResources(this.numberOfPeopleTextbox, "numberOfPeopleTextbox");
            this.numberOfPeopleTextbox.BackColor = System.Drawing.Color.MistyRose;
            this.numberOfPeopleTextbox.ForeColor = System.Drawing.Color.IndianRed;
            this.numberOfPeopleTextbox.Name = "numberOfPeopleTextbox";
            this.numberOfPeopleTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numberOfPeopleTextbox_KeyPress);
            // 
            // numberOfPeopleLabel
            // 
            resources.ApplyResources(this.numberOfPeopleLabel, "numberOfPeopleLabel");
            this.numberOfPeopleLabel.Name = "numberOfPeopleLabel";
            // 
            // extrasLabel
            // 
            resources.ApplyResources(this.extrasLabel, "extrasLabel");
            this.extrasLabel.Name = "extrasLabel";
            // 
            // doneButton
            // 
            resources.ApplyResources(this.doneButton, "doneButton");
            this.doneButton.BackColor = System.Drawing.Color.LemonChiffon;
            this.doneButton.ForeColor = System.Drawing.Color.Goldenrod;
            this.doneButton.Name = "doneButton";
            this.doneButton.UseVisualStyleBackColor = false;
            this.doneButton.Click += new System.EventHandler(this.doneButton_Click);
            // 
            // freeTicketsTextbox
            // 
            resources.ApplyResources(this.freeTicketsTextbox, "freeTicketsTextbox");
            this.freeTicketsTextbox.BackColor = System.Drawing.Color.MistyRose;
            this.freeTicketsTextbox.ForeColor = System.Drawing.Color.IndianRed;
            this.freeTicketsTextbox.Name = "freeTicketsTextbox";
            this.freeTicketsTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.freeTicketsTextbox_KeyPress);
            // 
            // freeTicketsLabel
            // 
            resources.ApplyResources(this.freeTicketsLabel, "freeTicketsLabel");
            this.freeTicketsLabel.Name = "freeTicketsLabel";
            // 
            // ReservationForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Controls.Add(this.freeTicketsLabel);
            this.Controls.Add(this.freeTicketsTextbox);
            this.Controls.Add(this.doneButton);
            this.Controls.Add(this.extrasLabel);
            this.Controls.Add(this.numberOfPeopleLabel);
            this.Controls.Add(this.numberOfPeopleTextbox);
            this.Controls.Add(this.fillThisFormLabel);
            this.Controls.Add(this.fullNameLabel);
            this.Controls.Add(this.ticketIsForLabel);
            this.Controls.Add(this.fullNameTextbox);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.radioButtonPanel);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "ReservationForm";
            this.radioButtonPanel.ResumeLayout(false);
            this.radioButtonPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel radioButtonPanel;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.TextBox fullNameTextbox;
        private System.Windows.Forms.Label ticketIsForLabel;
        private System.Windows.Forms.Label fullNameLabel;
        private System.Windows.Forms.Label fillThisFormLabel;
        private System.Windows.Forms.RadioButton radioButtonGroup;
        private System.Windows.Forms.RadioButton radioButtonFamily;
        private System.Windows.Forms.RadioButton radioButtonTwoPeople;
        private System.Windows.Forms.RadioButton radioButtonOnePerson;
        private System.Windows.Forms.TextBox numberOfPeopleTextbox;
        private System.Windows.Forms.Label numberOfPeopleLabel;
        private System.Windows.Forms.Label extrasLabel;
        private System.Windows.Forms.Button doneButton;
        private System.Windows.Forms.TextBox freeTicketsTextbox;
        private System.Windows.Forms.Label freeTicketsLabel;
    }
}