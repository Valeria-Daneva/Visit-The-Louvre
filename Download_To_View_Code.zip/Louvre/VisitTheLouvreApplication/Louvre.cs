﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisitTheLouvreApplication
{
    public partial class Louvre : Form
    {
        public Louvre()
        {
            InitializeComponent();
            MainPicture.Image = Properties.Resources.Dante;
            FirstPicture.Image = Properties.Resources.Dante;
            SecondPicture.Image = Properties.Resources.Death;
            ThirdPicture.Image = Properties.Resources.Homer;
            PictureName.SelectedIndex = 1;
            bookButton.Enabled = false;
            slideshowOnOffButton.Text = "Turn OFF slideshow";
        }

        int k = 1; 
        int second = 1;
        int t = 0;

        private void Louvre_Load(object sender, EventArgs e)
        {
            slideshowTimer.Start();
        }

        private void PictureNumber_ValueChanged(object sender, EventArgs e)
        {
            k = (int)PictureNumber.Value;
            if (k == 11)
            {
                k = 1;
                PictureNumber.Value = (decimal)k;
            }
            if (k == 0)
            {
                k = 10;
                PictureNumber.Value = (decimal)k;
            }
            switch (k)
            {
                case 1:
                    MainPicture.Image = Properties.Resources.Dante;
                    FirstPicture.Image = Properties.Resources.Dante;
                    SecondPicture.Image = Properties.Resources.Death;
                    ThirdPicture.Image = Properties.Resources.Homer;
                    PictureName.SelectedIndex = 1;
                    break;
                case 2:
                    MainPicture.Image = Properties.Resources.Death;
                    FirstPicture.Image = Properties.Resources.Dante;
                    SecondPicture.Image = Properties.Resources.Death;
                    ThirdPicture.Image = Properties.Resources.Homer;
                    PictureName.SelectedIndex = 2;
                    break;
                case 3:
                    MainPicture.Image = Properties.Resources.Homer;
                    FirstPicture.Image = Properties.Resources.Death;
                    SecondPicture.Image = Properties.Resources.Homer;
                    ThirdPicture.Image = Properties.Resources.Liberty;
                    PictureName.SelectedIndex = 3;
                    break;
                case 4:
                    MainPicture.Image = Properties.Resources.Liberty;
                    FirstPicture.Image = Properties.Resources.Homer;
                    SecondPicture.Image = Properties.Resources.Liberty;
                    ThirdPicture.Image = Properties.Resources.Madrid;
                    PictureName.SelectedIndex = 4;
                    break;
                case 5:
                    MainPicture.Image = Properties.Resources.Madrid;
                    FirstPicture.Image = Properties.Resources.Liberty;
                    SecondPicture.Image = Properties.Resources.Madrid;
                    ThirdPicture.Image = Properties.Resources.Medusa;
                    PictureName.SelectedIndex = 5;
                    break;
                case 6:
                    MainPicture.Image = Properties.Resources.Medusa;
                    FirstPicture.Image = Properties.Resources.Madrid;
                    SecondPicture.Image = Properties.Resources.Medusa;
                    ThirdPicture.Image = Properties.Resources.Napoleon;
                    PictureName.SelectedIndex = 6;
                    break;
                case 7:
                    MainPicture.Image = Properties.Resources.Napoleon;
                    FirstPicture.Image = Properties.Resources.Medusa;
                    SecondPicture.Image = Properties.Resources.Napoleon;
                    ThirdPicture.Image = Properties.Resources.Oath;
                    PictureName.SelectedIndex = 7;
                    break;
                case 8:
                    MainPicture.Image = Properties.Resources.Oath;
                    FirstPicture.Image = Properties.Resources.Napoleon;
                    SecondPicture.Image = Properties.Resources.Oath;
                    ThirdPicture.Image = Properties.Resources.Une;
                    PictureName.SelectedIndex = 8;
                    break;
                case 9:
                    MainPicture.Image = Properties.Resources.Une;
                    FirstPicture.Image = Properties.Resources.Oath;
                    SecondPicture.Image = Properties.Resources.Une;
                    ThirdPicture.Image = Properties.Resources.Wedding;
                    PictureName.SelectedIndex = 9;
                    break;
                case 10:
                    MainPicture.Image = Properties.Resources.Wedding;
                    FirstPicture.Image = Properties.Resources.Oath;
                    SecondPicture.Image = Properties.Resources.Une;
                    ThirdPicture.Image = Properties.Resources.Wedding;
                    PictureName.SelectedIndex = 10;
                    break;
            }
        }

        private void PictureName_SelectedIndexChanged(object sender, EventArgs e)
        {
            Change(PictureName.SelectedIndex);
        }

        private void areWeOpenButton_Click(object sender, EventArgs e)
        {
            DayOfWeek d1;
            DateTime d2;
            int f = 0;
                
            d1 = dateTimePicker1.Value.DayOfWeek;
            d2 = dateTimePicker1.Value;

            DateTime thisDay = DateTime.Today;

            if (DateTime.Compare(thisDay, dateTimePicker1.Value) > 0) MessageBox.Show("Please enter a date that hasn't already passed!");
            else 
            { 

            if ((d2.ToShortDateString().Contains("1.5.")) || (d2.ToShortDateString().Contains("1.1.")) || (d2.ToShortDateString().Contains("25.12.")))
                MessageBox.Show("Sorry! That's a holiday and we're closed!");
            else
                if ((d2.ToShortDateString().Contains("01/05/")) || (d2.ToShortDateString().Contains("01/01/")) || (d2.ToShortDateString().Contains("25/12/")))
                    MessageBox.Show("Sorry! That's a holiday and we're closed!");
                else
            { 
            switch (d1.ToString())
            {
                case "Monday": MessageBox.Show("We're open from 9:00 to 18:00!"); break;
                case "Tuesday": MessageBox.Show("Sorry! We're closed every Tuesday!"); f = 1; break;
                case "Wednesday": MessageBox.Show("We're open from 9:00 to 21:45!"); break;
                case "Thursday": MessageBox.Show("We're open from 9:00 to 18:00!"); break;
                case "Friday": MessageBox.Show("We're open from 9:00 to 21:45!"); break;
                case "Saturday": MessageBox.Show("We're open from 9:00 to 18:00!"); break;
                case "Sunday": MessageBox.Show("We're open from 9:00 to 18:00!"); break;
            }
                if (f == 0)
                {
                    monthCalendar1.RemoveAllBoldedDates();
                    monthCalendar1.AddBoldedDate(d2);
                    monthCalendar1.UpdateBoldedDates();

                    DateTime d3 = dateTimePicker1.Value.Date;
                    ReservationForm.date = d3.ToShortDateString();

                    bookButton.Enabled = true;
                    bookButton.Font = new System.Drawing.Font(bookButton.Font, System.Drawing.FontStyle.Bold);
                }
                else
                {
                    bookButton.Font = new System.Drawing.Font(bookButton.Font, System.Drawing.FontStyle.Regular);
                    bookButton.Enabled = false;
                    monthCalendar1.RemoveAllBoldedDates();
                }
            }
            }
        }
        
        private void bookButton_Click(object sender, EventArgs e)
        {
            if (bookButton.Enabled == false) MessageBox.Show("Check to see if we're open on the date you want to visit us on!");
            else
            {
                bookButton.Font = new System.Drawing.Font(bookButton.Font, System.Drawing.FontStyle.Regular);
                ReservationForm f = new VisitTheLouvreApplication.ReservationForm();
                f.Show();
            }         
        }

        public void Change(int k1)
        {
            if (k1 == 11)
            {
                k1 = 1;
                PictureName.SelectedIndex = k1;
            }
            if (k1 == 0)
            {
                k1 = 10;
                PictureName.SelectedIndex = k1;
            }
                switch (k1)
            {
                case 1:
                    MainPicture.Image = Properties.Resources.Dante;
                    FirstPicture.Image = Properties.Resources.Dante;
                    SecondPicture.Image = Properties.Resources.Death;
                    ThirdPicture.Image = Properties.Resources.Homer;
                    PictureNumber.Value = 1;
                    break;
                case 2:
                    MainPicture.Image = Properties.Resources.Death;
                    FirstPicture.Image = Properties.Resources.Dante;
                    SecondPicture.Image = Properties.Resources.Death;
                    ThirdPicture.Image = Properties.Resources.Homer;
                    PictureNumber.Value = 2;
                    break;
                case 3:
                    MainPicture.Image = Properties.Resources.Homer;
                    FirstPicture.Image = Properties.Resources.Death;
                    SecondPicture.Image = Properties.Resources.Homer;
                    ThirdPicture.Image = Properties.Resources.Liberty;
                    PictureNumber.Value = 3;
                    break;
                case 4:
                    MainPicture.Image = Properties.Resources.Liberty;
                    FirstPicture.Image = Properties.Resources.Homer;
                    SecondPicture.Image = Properties.Resources.Liberty;
                    ThirdPicture.Image = Properties.Resources.Madrid;
                    PictureNumber.Value = 4;
                    break;
                case 5:
                    MainPicture.Image = Properties.Resources.Madrid;
                    FirstPicture.Image = Properties.Resources.Liberty;
                    SecondPicture.Image = Properties.Resources.Madrid;
                    ThirdPicture.Image = Properties.Resources.Medusa;
                    PictureNumber.Value = 5;
                    break;
                case 6:
                    MainPicture.Image = Properties.Resources.Medusa;
                    FirstPicture.Image = Properties.Resources.Madrid;
                    SecondPicture.Image = Properties.Resources.Medusa;
                    ThirdPicture.Image = Properties.Resources.Napoleon;
                    PictureNumber.Value = 6;
                    break;
                case 7:
                    MainPicture.Image = Properties.Resources.Napoleon;
                    FirstPicture.Image = Properties.Resources.Medusa;
                    SecondPicture.Image = Properties.Resources.Napoleon;
                    ThirdPicture.Image = Properties.Resources.Oath;
                    PictureNumber.Value = 7;
                    break;
                case 8:
                    MainPicture.Image = Properties.Resources.Oath;
                    FirstPicture.Image = Properties.Resources.Napoleon;
                    SecondPicture.Image = Properties.Resources.Oath;
                    ThirdPicture.Image = Properties.Resources.Une;
                    PictureNumber.Value = 8;
                    break;
                case 9:
                    MainPicture.Image = Properties.Resources.Une;
                    FirstPicture.Image = Properties.Resources.Oath;
                    SecondPicture.Image = Properties.Resources.Une;
                    ThirdPicture.Image = Properties.Resources.Wedding;
                    PictureNumber.Value = 9;
                    break;
                case 10:
                    MainPicture.Image = Properties.Resources.Wedding;
                    FirstPicture.Image = Properties.Resources.Oath;
                    SecondPicture.Image = Properties.Resources.Une;
                    ThirdPicture.Image = Properties.Resources.Wedding;
                    PictureNumber.Value = 10;
                    break;
            }
        }

        private void slideshowTimer_Tick(object sender, EventArgs e)
        {
            second++;
            if (second == 5)
            {
                Change(k);
                k++;
                second = 1;
            }
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            dateTimePicker1.Value = monthCalendar1.SelectionStart;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            monthCalendar1.SetDate(dateTimePicker1.Value);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FirstPicture_Click(object sender, EventArgs e)
        {
            if ((k != 10) && (k != 1))
                if (t == 1) Change(k - 1);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k - 1);
                }
            else
            if (k == 1)
            {
                if (t == 1) Change(k);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k);
                }
            }
            else
            {
                if (t == 1) Change(k - 2);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k - 2);
                }
            }

        }

        private void SecondPicture_Click(object sender, EventArgs e)
        {
            if ((k != 10) && (k != 1))
                if (t == 1) Change(k);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k);
                }
            else
            if (k == 1)
            {
                if (t == 1) Change(k + 1);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k + 1);
                }
            }
            else
            {
                if (t == 1) Change(k - 1);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k - 1);
                }
            }
        }
        private void ThirdPicture_Click(object sender, EventArgs e)
        {
            if ((k != 10) && (k != 1))
                if (t == 1) Change(k + 1);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k + 1);
                }
            else
            if (k == 1)
            {
                if (t == 1) Change(k + 2);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k + 2);
                }
            }
            else
            {
                if (t == 1) Change(k);
                else
                {
                    slideshowTimer.Stop();
                    t = 1;
                    slideshowOnOffButton.Text = "Turn ON slideshow";
                    Change(k);
                }
            }
        }

        private void slideshowOnOffButton_Click(object sender, EventArgs e)
        {
            if(t == 0)
            { 
                slideshowTimer.Stop();
                t = 1;
                slideshowOnOffButton.Text = "Turn ON slideshow";
            }
            else
            {
                slideshowTimer.Start();
                t = 0;
                slideshowOnOffButton.Text = "Turn OFF slideshow";
            }
        }

        private void Louvre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Down)) Change((int)PictureNumber.Value + 1);
            if (e.KeyChar == Convert.ToChar(Keys.Up)) Change((int)PictureNumber.Value - 1);
        }
    }
}

