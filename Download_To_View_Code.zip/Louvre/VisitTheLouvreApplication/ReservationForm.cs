﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisitTheLouvreApplication
{
    public partial class ReservationForm : Form
    {
        public ReservationForm()
        {
            InitializeComponent();
            numberOfPeopleLabel.Visible = false;
            numberOfPeopleTextbox.Visible = false;

            freeTicketsLabel.Visible = false;
            freeTicketsTextbox.Visible = false;
        }
        //declaring the info variable as blank/only having an interval so as to add the information about attendance later
        //the varaible is meant to store how the user will arrive
        string info = " ";
        //the date variable is meant to store the date the user last chose before they opened the booking/calculation form
        static public string date;

        //making sure only numbers are entered into the number of people textbox
        private void numberOfPeopleTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9')) return;
            e.Handled = true;
        }

        //making sure only numbers are entered into the free tickets textbox
        private void freeTicketsTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9')) return;
            e.Handled = true;
        }

        //making sure only letters and intervals are entered into the full name textbox
        private void fullNameTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 'A') && (e.KeyChar <= 'z') || (e.KeyChar == ' ')) return;
            e.Handled = true;
        }

        //click on back button to return to previous form 
        private void backButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Louvre l = new VisitTheLouvreApplication.Louvre();
            l.Show();
            this.Close();
        }

        //adding a message to the info variable that the person is arriving alone
        //when that radio button is pushed
        private void radioButtonOnePerson_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonOnePerson.Checked == true)
                info = info + "is going to arrive alone";
            if (radioButtonOnePerson.Checked == false)
                info = " ";
        }//radioButtonOnePerson_CheckedChanged function

        //adding a message to the info variable that the person is arriving
        //with another person when that radio button is pushed
        private void radioButtonTwoPeople_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonTwoPeople.Checked == true)
            {
                info = info + "is going to arrive with another person";

                freeTicketsLabel.Visible = true;
                freeTicketsTextbox.Visible = true;
            }
            if (radioButtonTwoPeople.Checked == false)
            {
                info = " ";

                freeTicketsLabel.Visible = false;
                freeTicketsTextbox.Visible = false;
            }
        }//radioButtonTwoPeople_CheckedChanged function

        private void radioButtonFamily_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonFamily.Checked == true)
            {
                numberOfPeopleLabel.Visible = true;
                numberOfPeopleTextbox.Visible = true;

                freeTicketsLabel.Visible = true;
                freeTicketsTextbox.Visible = true;
            }
            else
            {
                numberOfPeopleLabel.Visible = false;
                numberOfPeopleTextbox.Visible = false;

                freeTicketsLabel.Visible = false;
                freeTicketsTextbox.Visible = false;
                info = " ";
            }

        }//radioButtonFamily_CheckedChanged function

        private void radioButtonGroup_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonGroup.Checked == true)
            {
                numberOfPeopleLabel.Visible = true;
                numberOfPeopleTextbox.Visible = true;

                freeTicketsLabel.Visible = true;
                freeTicketsTextbox.Visible = true;
            }
            else
            {
                numberOfPeopleLabel.Visible = false;
                numberOfPeopleTextbox.Visible = false;

                freeTicketsLabel.Visible = false;
                freeTicketsTextbox.Visible = false;
                info = " ";
            }

        }//radioButtonGroup_CheckedChanged function


        private void doneButton_Click(object sender, EventArgs e)
        {
            //declaring extras and result variable
            string extras = "";
            string resultingMessage = "";

            double sumOfCost = 0;
            int numberOfTicketsToBuy = 0; 

            //adding every checked item to the extras variable as listed items
            foreach (string itemChecked in checkedListBox1.CheckedItems)
            {
                extras += itemChecked + ", ";

                switch(itemChecked)
                {
                    case "audio guide": sumOfCost += 2.37; break;
                    case "passport for all museums": sumOfCost += 75.50; break;
                    case "two-day ticket": sumOfCost += 20.75; break;
                    case "week ticket": sumOfCost += 72.40; break;
                }
            }

            if (extras != "")
            {
                int index = extras.Length - 2;
                extras = extras.Remove(index, 2);
                if (extras.Contains(',') == true)
                {
                    extras = extras.Insert(extras.LastIndexOf(','), " and a/an");
                    extras = extras.Remove(extras.LastIndexOf(','), 1);
                } 
            }
            
            if ((fullNameTextbox.Text == "")||(fullNameTextbox.Text == " "))
               MessageBox.Show("Please enter your forename and your surname!");
            else
            {
                string name = fullNameTextbox.Text;
                if ((name.Contains(" ") == false)||(name.LastIndexOf(" ") == name.Length - 1))
                   MessageBox.Show("Please enter your surname!");
                else
                {
                    if (radioButtonFamily.Checked == true)
                 {
                    if (numberOfPeopleTextbox.Text == "")
                        MessageBox.Show("Please enter the number of people within your family!");
                    else 
                    {
                      
                        int numberOfPeopleTotal = int.Parse(numberOfPeopleTextbox.Text);
                        info = info + "will arrive with a family of " + numberOfPeopleTextbox.Text + " people";

                        if (freeTicketsTextbox.Text == "")
                            MessageBox.Show("Please enter the number of people eligible for a free ticket!");
                        else if (numberOfPeopleTotal < int.Parse(freeTicketsTextbox.Text))
                            MessageBox.Show("Please enter a valid number of people eligible for a free ticket!");
                        else
                        {
                            numberOfTicketsToBuy = numberOfPeopleTotal - int.Parse(freeTicketsTextbox.Text);
                            sumOfCost += numberOfTicketsToBuy * 15;

                            resultingMessage = fullNameTextbox.Text + info + " and is to be given a/an "
                                + (extras != " " ? extras : "") + ". They will arrive on " + date
                                + ". This will cost them a total of €" + Math.Round((sumOfCost * 0.9), 2)
                                + ", because there is a 10% discount for families.";
                            MessageBox.Show(resultingMessage);
                            info = " ";

                        }
                    }

            } 
            else if (radioButtonGroup.Checked == true)
            {
                //Enter number of people error
                if (numberOfPeopleTextbox.Text == "")
                   MessageBox.Show("Please enter the number of people your group will consist of!");                      
                
                else
                {
                    //adding the number of people to the end message, as taken from the textbox
                    int numberOfPeopleTotal = int.Parse(numberOfPeopleTextbox.Text);
                    info = info + "will arrive with a group consisting of " + numberOfPeopleTextbox.Text + " people";

                    if (freeTicketsTextbox.Text == "")
                        MessageBox.Show("Please enter the number of people eligible for a free ticket!");
                    else if (numberOfPeopleTotal < int.Parse(freeTicketsTextbox.Text))
                            MessageBox.Show("Please enter a valid number of people eligible for a free ticket!");
                    else
                    {
                        numberOfTicketsToBuy = numberOfPeopleTotal - int.Parse(freeTicketsTextbox.Text);
                        sumOfCost += numberOfTicketsToBuy * 15;
                        
                        resultingMessage = fullNameTextbox.Text + info + " and is to be given a/an " 
                            + (extras != " " ? extras : "") + ". They will arrive on " + date 
                            + ". This will cost them a total of €" + Math.Round((sumOfCost * 0.75), 2)
                            + ", because there is a 25% discount for organised groups.";
                        MessageBox.Show(resultingMessage);
                        info = " ";

                     }

                }//else no number of people error

            }//if radioButtonGroup is checken/chosen
            else
            {
               if(radioButtonTwoPeople.Checked == true)
               { 
                    if (freeTicketsTextbox.Text == "")
                        MessageBox.Show("Please enter the number of people eligible for a free ticket!");
                    else if (2 < int.Parse(freeTicketsTextbox.Text))
                            MessageBox.Show("Please enter a valid number of people eligible for a free ticket!");
                    else
                    {
                        numberOfTicketsToBuy = 2 - int.Parse(freeTicketsTextbox.Text);
                        sumOfCost += numberOfTicketsToBuy * 15;

                        resultingMessage = fullNameTextbox.Text + info + " and is to be given a/an " 
                            + (extras != " " ? extras : "") + ". They will arrive on " + date 
                            + ". This will cost them a total of €" + sumOfCost;
                        MessageBox.Show(resultingMessage);

                    }

               }//if two people option is chosen
               else
               {
                     resultingMessage = fullNameTextbox.Text + info + " and is to be given a/an " 
                         + (extras != " "? extras : "") + ". They will arrive on " + date 
                         + ". This will cost them a total of either €" + sumOfCost 
                         + " or €" + (sumOfCost + 15) + ", depending on whether they're eligible for a free ticket or not.";
                     MessageBox.Show(resultingMessage);

                }//else radioButtonFamily, radioButtonGroup and radioButtonTwoPeople aren't checked

              }//else radioButtonFamily and radioButtonGroup aren't checked

            }//else everything is filled up(name & numbers)

          }//else name(at least forename) is filled      
                               
        }//end of clicking doneButton function


    }//end of ReservationForm

}//end namespace VisitTheApplication

